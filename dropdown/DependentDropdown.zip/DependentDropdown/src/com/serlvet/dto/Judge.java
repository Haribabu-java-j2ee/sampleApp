package com.serlvet.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Judge {
	private int id;
	private String name;
	
}
