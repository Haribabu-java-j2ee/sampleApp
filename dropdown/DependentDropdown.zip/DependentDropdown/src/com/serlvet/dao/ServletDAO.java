package com.serlvet.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.serlvet.dto.Category;
import com.serlvet.dto.Judge;
import com.serlvet.dto.Location;
 
public class ServletDAO {
    String databaseURL = "jdbc:mysql://db4free.net:3306/statedb";
    String user = "statedb";
    String password = "read1234";
    private Connection connection=null;
  /*  private ServletDAO(){
    	
    }*/
    public Connection getInstance() throws SQLException, ClassNotFoundException{
    	if(connection!=null){
    		return connection;
    	}else {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		 connection = DriverManager.getConnection(databaseURL, user, password);
    		return connection;
    	}
    }
  /*  public List<Category> list() throws SQLException {
        List<Category> listCategory = new ArrayList<>();
         
        try (Connection connection = DriverManager.getConnection(databaseURL, user, password)) {
            String sql = "SELECT * FROM category ORDER BY name";
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(sql);
             
            while (result.next()) {
                int id = result.getInt("category_id");
                String name = result.getString("name");
                Category category = new Category(id, name);
                     
                listCategory.add(category);
            }          
             
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw ex;
        }      
         
        return listCategory;
    }*/
    
    public List<Judge> getJudgeList(Connection con) throws SQLException{
    	List<Judge> judgeLst=new ArrayList<Judge>();
    	if(con!=null){
    		 String sql = "SELECT id,name FROM judge";
             Statement statement = con.createStatement();
             ResultSet result = statement.executeQuery(sql);
              
             while (result.next()) {
                 int id = result.getInt("id");
                 String name = result.getString("name");
                 Judge judgeObj = new Judge(id, name);
                      
                 judgeLst.add(judgeObj);
             }          
              
    	}
    	return judgeLst;
    }
    public List<Judge> getJudgeList(){
    	List<Judge> judgeLst=new ArrayList<Judge>();
    	judgeLst.add(new Judge(1, "Hari"));
    	judgeLst.add(new Judge(2, "babu"));
    	judgeLst.add(new Judge(3, "raju"));
    	judgeLst.add(new Judge(4, "ravi"));
    	return judgeLst;
    }
    
    public List<Category> getCategoryLis(){
    	List<Category> categoryLst=new ArrayList<Category>();
    	categoryLst.add(new Category(1, "Civil"));
    	categoryLst.add(new Category(2, "Criminal"));
    	categoryLst.add(new Category(3, "Retired"));
    	return categoryLst;
    }
    
    public List<Location> getLocations(int judgeId){
    	List<Location> locationLst=new ArrayList<Location>();
    	locationLst.add(new Location(1, "Chennai"));
    	locationLst.add(new Location(2, "Hyderabad"));
    	locationLst.add(new Location(3, "Bangalore"));
    	locationLst.add(new Location(4, "Mumbai"));
    	return locationLst;
    }
}