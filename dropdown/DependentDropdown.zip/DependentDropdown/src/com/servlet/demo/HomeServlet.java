package com.servlet.demo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.serlvet.dao.ServletDAO;
import com.serlvet.dto.Judge;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
	/**
	 * default serial id
	 */
	private static final long serialVersionUID = 1L;
	
	private Connection con;
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("Inside GET method");
		ServletDAO servletDAOObj = new ServletDAO();
		request.setAttribute("judgeList", servletDAOObj.getJudgeList());
		if (request.getParameter("judge") != null && Integer.parseInt(request.getParameter("judge")) != 0) {
			System.out.println(request.getParameter("judge"));
			request.setAttribute("locationLst",
					servletDAOObj.getLocations(Integer.parseInt(request.getParameter("judge"))));
		}
		request.setAttribute("categoryList", servletDAOObj.getCategoryLis());
		request.getRequestDispatcher("/WEB-INF/jsp/welcome.jsp").forward(request, response);
	}

	//if data base connection is available
	private List<Judge> getJudgeList() throws ClassNotFoundException, SQLException{
		ServletDAO servletDAOObj = new ServletDAO();
		con=servletDAOObj.getInstance();
		return servletDAOObj.getJudgeList(con);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Inside POST");
		super.doPost(req, resp);
	}
}
