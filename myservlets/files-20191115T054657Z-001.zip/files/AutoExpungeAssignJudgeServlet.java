package gov.utcourts.corisweb.servlet;

import gov.utcourts.coriscommon.dataaccess.autoexpungementsigningjudge.AutoExpungementSigningJudgeBO;
import gov.utcourts.coriscommon.dataaccess.location.LocationBO;
import gov.utcourts.coriscommon.dataaccess.personnel.PersonnelBO;
import gov.utcourts.coriscommon.enumeration.PageMode;
import gov.utcourts.coriscommon.util.TextUtil;
import gov.utcourts.coriscommon.xo.AutoExpungeXO;
import gov.utcourts.corisweb.session.SessionVariables;
import gov.utcourts.corisweb.util.CorisAttorneyUtil;
import gov.utcourts.corisweb.util.URLEncryption;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

/**
* Servlet implementation class AutoExpungeAssignJudgeServlet
*/
@WebServlet("/AutoExpungeAssignJudgeServlet")
public class AutoExpungeAssignJudgeServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;

	private static Logger logger = Logger.getLogger(AutoExpungeAssignJudgeServlet.class.getName());
     
	/**
   	* @see HttpServlet#HttpServlet()
   	*/
	public AutoExpungeAssignJudgeServlet() {
	  super();
  	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void performTask(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String page = "";

			String courtType = URLEncryption.getParamAsString(request, "courtType"); //get passed in value			

			String locnCode = URLEncryption.getParamAsString(request, "locnCode"); //get passed in value
			
			String judgeId = URLEncryption.getParamAsString(request, "judge"); //get passed in value
		 
			String logName = (String) request.getSession().getAttribute(SessionVariables.LOG_NAME); //default

			if(logName == null || "".equals(logName)) {
				page = "/login.jsp";
				getServletContext().getRequestDispatcher(page).forward(request, response);
			} else {
			
				PageMode mode = PageMode.resolveEnumFromString(URLEncryption.getParamAsString(request, "mode"));
				System.out.println("mode------------"+mode);
			 
				switch (mode) {
					case GETJUDGES:
						getActiveJudges(request, response, courtType, locnCode);
						break;
						
					case SAVE:
						saveActiveJudges(request, response, new Integer(judgeId), locnCode,courtType);					 
						break;
						
					case DELETE:
						deleteJudge(request, response, new Integer(judgeId),courtType);					 
						break;
				 
						 
					default:
						defaultPage(request, response);
						break;
				}	
				mode = null;			 
				courtType = null;
				locnCode = null;			 
				logName = null;
			}
		} catch (Exception e){
			request.setAttribute("errorMessage", "An error occured and the page could not be loaded properly.");
			logger.error("AutoExpungeAssignJudgeServlet performTask(HttpServletRequest request, HttpServletResponse response)", e);
		}
	}
	
	private void getActiveJudges(HttpServletRequest request, HttpServletResponse response, String courtType, String locnCode) throws ServletException, IOException {		
		
		JSONObject retValObj = new JSONObject();
		String errorMessage = "";		
		try{
			List<PersonnelBO>  judges= AutoExpungeXO.getActiveJudgesByLocationAndCourt(locnCode, courtType);
			
			if(judges != null && judges.size()>0)
			{
				JSONArray retValArr = new JSONArray();
				for (PersonnelBO judge : judges) {
					JSONObject jsonObject = new JSONObject();
					jsonObject.put("logName", judge.getLogname());
					jsonObject.put("useridSrl", judge.getUseridSrl());
					jsonObject.put("firstName", judge.getFirstName());
					jsonObject.put("lastName", judge.getLastName());
					retValArr.add(jsonObject);
				}
				retValObj.put("judgeList", retValArr);
			}
			
			else
			{
				errorMessage = "No Judges found for courtType="+courtType + "locnCode"+locnCode;
			}			
			 
		}catch(Exception e){
			errorMessage += "There was an error while getting judges.<br>";
		}
		if (!TextUtil.isEmpty(errorMessage)) {
			retValObj.put("error", true);
			retValObj.put("errorMessage", errorMessage);
		}else{
			retValObj.put("error", false);
		}
		response.setContentType("application/json");
		response.setHeader("Cache-Control", "no-cache");
		response.getWriter().write(retValObj.toString());
		retValObj = null;
		errorMessage = null;
		
	}
	
private void saveActiveJudges(HttpServletRequest request, HttpServletResponse response,Integer judgeId, String  locnCode, String courtType) throws ServletException, IOException {		
		
	
		String page = "/jsp/autoExpungeAssignJudge.jsp";
		try{ 
			
			AutoExpungeXO.saveSigningJudge(judgeId, locnCode, courtType);
		    List<AutoExpungementSigningJudgeBO> signJudgeList = AutoExpungeXO.getAllSigningJudge(courtType);
		
			
			//get location lists
			List<LocationBO> locationDistrictListBO = CorisAttorneyUtil.getLocationList(request, "D");
			List<LocationBO> locationJusticeListBO = CorisAttorneyUtil.getLocationList(request, "J");
			request.setAttribute("locationDistrictList", locationDistrictListBO);
			request.setAttribute("locationJusticeList", locationJusticeListBO);
			request.setAttribute("signJudgeList", signJudgeList);
		 
			getServletContext().getRequestDispatcher(page).forward(request, response);
			page = null;
			
		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("errorMessage", "There was an error while saving judge.");
			log.error("There was an error while saving judge "+e.getMessage());
			
		}
	
		
	}


private void deleteJudge(HttpServletRequest request, HttpServletResponse response,Integer judgeId,String courtType) throws ServletException, IOException {		
	
	
	String page = "/jsp/autoExpungeAssignJudge.jsp";
	try{ 
		
		AutoExpungeXO.deleteSigningJudge(judgeId, courtType);
	    List<AutoExpungementSigningJudgeBO> signJudgeList = AutoExpungeXO.getAllSigningJudge(courtType);
	
		
		//get location lists
		List<LocationBO> locationDistrictListBO = CorisAttorneyUtil.getLocationList(request, "D");
		List<LocationBO> locationJusticeListBO = CorisAttorneyUtil.getLocationList(request, "J");
		request.setAttribute("locationDistrictList", locationDistrictListBO);
		request.setAttribute("locationJusticeList", locationJusticeListBO);
		request.setAttribute("signJudgeList", signJudgeList);
	 
		getServletContext().getRequestDispatcher(page).forward(request, response);
		page = null;
		
	}catch(Exception e){
		e.printStackTrace();
		request.setAttribute("errorMessage", "There was an error while saving judge.");
		log.error("There was an error while saving judge "+e.getMessage());
		
	}

	
}
	

	private void defaultPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String page = "/jsp/autoExpungeAssignJudge.jsp";
		
		 
		List<LocationBO> locationDistrictListBO = CorisAttorneyUtil.getLocationList(request, "D");
		List<LocationBO> locationJusticeListBO = CorisAttorneyUtil.getLocationList(request, "J");
		List<AutoExpungementSigningJudgeBO> signJudgeList = AutoExpungeXO.getAllSigningJudge("D");
		request.setAttribute("locationDistrictList", locationDistrictListBO);
		request.setAttribute("locationJusticeList", locationJusticeListBO);
		request.setAttribute("signJudgeList", signJudgeList);
		 
	 
		getServletContext().getRequestDispatcher(page).forward(request, response);
		page = null;
	}
	
	
	
	 
}
